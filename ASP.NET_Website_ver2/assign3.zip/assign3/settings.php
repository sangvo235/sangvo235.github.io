<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s104020390"; // your user name
	$pwd = "230698"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s104020390_db"; // your database
?>

