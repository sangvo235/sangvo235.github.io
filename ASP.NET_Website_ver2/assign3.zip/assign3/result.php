<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href ="styles/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">
    <script src="scripts/result.js"></script>
    <title>Quiz Results</title>
</head>

<body>
    <script src="scripts/enhancements.js"></script>
    <script>
// to start within 0.5 seconds of loading 
var start = () => {
    setTimeout(function() {
        confetti.start();
    }, 500); 
};

// to stop within 10 seconds of loading 
var stop = () => {
    setTimeout(function() {
        confetti.stop();
    }, 10000)
}
start();
stop();
</script>
    <div class="result_header">
    <h1>Quiz Data Summary</h1></div>

    <div class="quizresults">
        <p>Student ID: <span id="studentid_r"></span></p> 
        <p>First Name: <span id="firstname_r"></span></p> 
        <p>Last Name: <span id="lastname_r"></span></p> 
        <p>Score: <span id="score_r"></span></p> 
        <p>Number of Attempts: <span id="count_r"></span></p> 
        <p><span id="retry"><a href="quiz.html">Try Again!</a></span></p> 
    </div>
</body>
</html>

